A module that adds sequence to the product.
===========================================

This module allows to associate a sequence to the product reference.
The reference (default code) is unique (SQL constraint) and required.

Credits
=======

Contributors
------------

* Angel Moya <angel.moya@domatix.com>

Maintainer
----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose mission is to support the collaborative development of Odoo features and promote its widespread use.

To contribute to this module, please visit http://odoo-community.org.
