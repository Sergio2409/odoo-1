[![Build Status](https://travis-ci.org/OCA/product-attribute.svg?branch=8.0)](https://travis-ci.org/OCA/product-attribute)
[![Coverage Status](https://coveralls.io/repos/OCA/product-attribute/badge.png?branch=8.0)](https://coveralls.io/r/OCA/product-attribute?branch=8.0)

Odoo Product Attribute
======================

Various addons related to attribute management for products.
