Get back sales orders to draft
==============================

Allows to get back to draft any cancelled sale order.

Installation
============

Nothing special is needed to install this module.

Configuration
=============

Nothing special is needed to configure this module.

Usage
=====

When you cancel a sale order, you will see a new button call *Back to draft*,
that resets the sale order to draft state.

Known issues / Roadmap
======================

None known.

Credits
=======

Contributors
------------
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>


Maintainer
----------

.. image:: http://odoo-community.org/logo.png
   :alt: Odoo Community Association
   :target: http://odoo-community.org

This module is maintained by the OCA.

OCA, or the Odoo Community Association, is a nonprofit organization whose mission is to support the collaborative development of Odoo features and promote its widespread use.

To contribute to this module, please visit http://odoo-community.org.
